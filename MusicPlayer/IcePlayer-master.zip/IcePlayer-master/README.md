# IcePlayer
A Music Player using QT5 and VS2013
## Here some pics and screen shots  
![](http://www.tekbroaden.com/wp-content/uploads/2015/04/%E5%86%B0%E7%82%B9%E6%92%AD%E6%94%BE%E5%99%A8%E5%AE%A3%E4%BC%A02-1024x615.jpg)  
![](http://www.tekbroaden.com/wp-content/uploads/2015/04/%E6%92%AD%E6%94%BE%E5%99%A8%E7%9A%AE%E8%82%A44-1-1024x683.jpg) 
![](http://www.tekbroaden.com/wp-content/uploads/2015/04/%E4%B8%BB%E7%95%8C%E9%9D%A2.png)  
## V2.0 主要更新内容  

### 新增功能：  

网络歌词、专辑图片获取（保存在歌曲目录下，文件名与歌曲同名）  
拖拽加歌现在可以一次性添加多首，且可以自动识别文件类型，只添加mp3文件
拖动播放进度条时，松开鼠标才更新播放进度，不会再有刺耳的声音啦~  
播放器内字体更换为微软雅黑  
播放列表显示效果优化  
桌面歌词显示效果、拖动效果优化  
软件改为纯绿色版本，解压即可使用，可以在“打开方式”中指定为默认mp3播放器  
优化内存占用，虽然添加了网络模块，但是资源占用没有明显提升  

### 修复已知的一些BUGs：  
  
修正部分中文字体乱码问题（如还有乱码欢迎向我反馈）  
修正播放按钮有时跟播放状态不一致的问题  
修正已知的崩溃BUG  
修正播放列表中显示”失效“的状态无法自动解除的问题  
修正桌面歌词有时会串词的问题  
修正迷你模式下有时播放按钮状态跟主界面不一致的问题  
### 下载地址：
（免安装绿色版）百度云盘下载链接：[http://pan.baidu.com/s/1o6if5xS](http://pan.baidu.com/s/1o6if5xS) 密码：tjfi  

